# Mesh Implementation Specification

## Overview

The NEXUS Mesh is a **three-layer hybrid architecture** that enables federated coordination between healthcare organizations while preserving data sovereignty and ensuring compliance.

---

## Architecture Layers

### Layer 1: Federated APIs (Synchronous)

**Purpose**: Real-time request/response for immediate data needs

**Protocols**:
- SMART-on-FHIR R4+
- OAuth 2.0 + OIDC for authentication
- mTLS (mutual TLS) for transport security

**Use Cases**:
- Pull medication list from Hospital A
- Post consult response to Hospital B  
- Request authorization from Insurance
- Query patient data with consent token

**Standards**:
- HL7 FHIR R4+ (data format)
- OAuth 2.0 (authorization)
- OIDC (authentication)
- X.509 certificates (mTLS)

**Example Request**:
```http
GET /Patient/12345/MedicationStatement
Host: hospital-a.nexus.health
Authorization: Bearer {consent_token}
X-Client-Cert: {org_certificate}
```

---

### Layer 2: Event-Driven Mesh (Asynchronous)

**Purpose**: Loosely-coupled workflow coordination and notifications

**Architecture**:
- Org-local event gateway (Kafka, AWS EventBridge, Azure Event Grid)
- Cross-org routing via MCP (Model Context Protocol)
- Store-and-forward with idempotent replay

**Event Types**:
```yaml
events:
  - procedure.performed
  - consult.response  
  - notify.family
  - discharge.ready
  - auth.decision
  - lab.critical
  - observer.alert
```

**Event Schema**:
```json
{
  "event_id": "evt_abc123",
  "event_type": "procedure.performed",
  "timestamp": "2025-11-04T15:30:00Z",
  "source_org": "hospital-a",
  "patient_id": "PAT-847392",
  "consent_scope": "treatment",
  "payload": {
    "procedure": "cardiac_catheterization",
    "status": "completed",
    "performer": "Dr. Smith",
    "results_available": true
  },
  "signature": "0xabc..."
}
```

**Resilience**:
- Events queue locally during mesh outage
- Automatic retry with exponential backoff
- Idempotent processing (duplicate detection)
- Gap window logging for audit

---

### Layer 3: Signed Audit Ledger

**Purpose**: Immutable, tamper-evident audit trail

**Technology**:
- AWS QLDB or Azure Confidential Ledger
- Append-only (no deletes/updates)
- Cryptographic verification (Merkle trees)
- Optional Bitcoin/Ethereum anchoring

**Ledger Entry Schema**:
```json
{
  "transaction_id": "txn_abc123",
  "timestamp": "2025-11-04T15:30:05Z",
  "document_hash": "sha256:0xabc123...",
  "author_signature": "0x789def...",
  "org_signature": "0x321fed...",
  "consent": {
    "patient_id": "PAT-847392",
    "authorized_recipients": ["hospital-b"],
    "purpose": "treatment",
    "scope": "discharge_summary",
    "expires": "2026-11-04T15:30:05Z"
  },
  "merkle_path": ["0xdef...", "0xghi...", "0xjkl..."],
  "merkle_root": "0xmno...",
  "anchor": {
    "chain": "bitcoin",
    "block": 850123,
    "tx_hash": "0xpqr..."
  }
}
```

**Verification Process**:
1. Hash the document: `SHA-256(document)`
2. Verify author signature over hash
3. Verify org countersignature
4. Check ledger entry matches
5. Verify Merkle inclusion proof
6. (Optional) Check blockchain timestamp

---

## Integration Patterns

### Pattern 1: Care Transition (Hospital A → Hospital B)

```
Day 0: Patient discharged from Hospital A

1. Doctor completes discharge summary in Epic EHR
2. AI generates FHIR Composition (standardized format)
3. Doctor reviews and signs electronically (RSA-4096)
4. Hospital A countersigns (institutional attestation)
5. Event published: "patient.transfer.initiated"
6. Hospital B receives event notification
7. Hospital B calls API: GET /Patient/12345/summary
8. Hospital A sends signed FHIR bundle
9. Both orgs record to ledger:
   - Hospital A: {hash, signatures, timestamp, consent}
   - Hospital B: {hash, received_ack, timestamp}
10. Observer monitors: consent valid, transfer appropriate

Day 1: Patient arrives at Hospital B

1. Clinician opens discharge summary
2. Reviews diagnoses, meds, allergies, care plan
3. Needs additional detail: "Last echocardiogram?"
4. Queries Hospital A: GET /DiagnosticReport/echo
5. Hospital A validates consent token, returns data
6. Hospital B logs query + response
7. Care continues seamlessly

Offline Fallback:

If Hospital A unavailable:
1. Hospital B retrieves from patient wallet (QR code)
2. Patient shows encrypted summary on phone
3. Hospital B scans, verifies signatures
4. Sufficient info to initiate treatment
5. Query Hospital A later when online
```

### Pattern 2: Insurance Authorization

```
Doctor orders MRI for patient

1. Order entered in EHR
2. Event published: "auth.request.created"
3. Insurance AI receives notification
4. Queries EHR for clinical justification:
   - Diagnosis codes (ICD-10)
   - Prior treatments attempted
   - Clinical notes excerpt
5. AI evaluates against coverage policy
6. Decision:
   - APPROVED: Event "auth.approved" + reference number
   - DENIED: Event "auth.denied" + reason + appeal info
7. If denied:
   - Patient AI auto-generates appeal with evidence
   - Submits to insurance  
   - Escalates to human if needed
8. All steps logged to ledger
9. Observer monitors: Was decision fair? Timely?
```

### Pattern 3: Family Coordination

```
Patient in ICU, family wants updates

1. Patient pre-authorized family member access
2. Family member opens app
3. Sees curated update (NOT raw chart):
   "Dad is stable. Breathing support continues. 
    Labs improving. Expect discharge discussion tomorrow."
4. Family can ask questions:
   "What does 'breathing support' mean?"
5. AI explains in plain language
6. Family CANNOT access:
   - Detailed clinical notes
   - Specific lab values (unless patient grants)
   - Provider communications
7. All family access logged (consent-bounded)
8. Patient can revoke access anytime
```

---

## Consent Management

### Consent Token Format (JWT)

```json
{
  "sub": "PAT-847392",
  "iss": "hospital-a.nexus.health",
  "aud": ["hospital-b.nexus.health"],
  "iat": 1699113005,
  "exp": 1730649005,
  "purpose": "treatment",
  "scope": {
    "resources": ["MedicationStatement", "Condition", "AllergyIntolerance"],
    "operations": ["read"],
    "time_range": {
      "start": "2024-01-01",
      "end": "2025-12-31"
    }
  },
  "patient_signature": "0xabc...",
  "issuer_signature": "0xdef..."
}
```

### Consent Scopes

```yaml
scopes:
  emergency:
    description: "Life-threatening emergency access"
    resources: ["*"]
    operations: ["read", "create"]
    requires_patient: false
    audit_level: high
    
  treatment:
    description: "Routine treatment coordination"
    resources: ["MedicationStatement", "Condition", "Procedure"]
    operations: ["read"]
    requires_patient: true
    audit_level: medium
    
  family:
    description: "Family member view access"
    resources: ["summary"]
    operations: ["read"]
    requires_patient: true
    audit_level: medium
    
  billing:
    description: "Billing and authorization"
    resources: ["Condition", "Procedure"]
    operations: ["read"]
    requires_patient: true
    audit_level: medium
    
  research:
    description: "De-identified research"
    resources: ["*"]
    operations: ["read"]
    requires_patient: true
    pii_scrubbed: true
    audit_level: high
```

---

## Error Handling

### API Error Responses

```json
{
  "error": {
    "code": "CONSENT_DENIED",
    "message": "Patient has not authorized this query",
    "details": {
      "patient_id": "PAT-847392",
      "requested_scope": "MedicationStatement.read",
      "authorized_scopes": ["Condition.read"],
      "suggestion": "Request patient consent for MedicationStatement access"
    },
    "trace_id": "trace_xyz789"
  }
}
```

### Retry Logic

```yaml
retry_policy:
  transient_errors:
    - NETWORK_TIMEOUT
    - SERVICE_UNAVAILABLE
    - RATE_LIMIT_EXCEEDED
  max_attempts: 3
  backoff: exponential
  base_delay: 1s
  max_delay: 30s
  
  permanent_errors:
    - CONSENT_DENIED
    - RESOURCE_NOT_FOUND
    - INVALID_TOKEN
  max_attempts: 1
  action: fail_fast
```

---

## Performance Targets

```yaml
latency:
  api_p50: 100ms
  api_p95: 500ms
  api_p99: 2s
  
  event_delivery_p50: 1s
  event_delivery_p95: 5s
  event_delivery_p99: 30s
  
  ledger_write_p50: 500ms
  ledger_write_p95: 2s

throughput:
  api_requests: 10,000/second (per mesh node)
  event_ingestion: 50,000/second (per mesh node)
  ledger_writes: 1,000/second (global)

availability:
  mesh_uptime: 99.9% (43 min downtime/month)
  ledger_uptime: 99.99% (4.3 min downtime/month)
  
scalability:
  hospitals: 1,000+ per mesh node
  patients: 10M+ per mesh node
  horizontal_scaling: yes
```

---

## Security

### mTLS Configuration

```yaml
tls_version: 1.3
cipher_suites:
  - TLS_AES_256_GCM_SHA384
  - TLS_CHACHA20_POLY1305_SHA256
  - TLS_AES_128_GCM_SHA256

certificate_validation:
  - verify_peer: true
  - verify_hostname: true
  - check_crl: true
  - check_ocsp: true
  
client_certificates:
  required: true
  ca_bundle: /etc/nexus/ca-bundle.pem
  revocation_check: crl_and_ocsp
```

### Rate Limiting

```yaml
rate_limits:
  per_organization:
    api_requests: 1000/minute
    event_publishes: 5000/minute
    ledger_writes: 100/minute
    
  per_user:
    api_requests: 100/minute
    data_queries: 50/minute
    
  per_patient:
    family_access: 20/minute
    consent_updates: 10/minute
```

---

## Monitoring & Observability

### Metrics

```yaml
mesh_metrics:
  - api_requests_total (counter)
  - api_request_duration_seconds (histogram)
  - event_publishes_total (counter)
  - event_delivery_lag_seconds (histogram)
  - ledger_writes_total (counter)
  - ledger_write_duration_seconds (histogram)
  - consent_checks_total (counter)
  - consent_denials_total (counter)
  - mtt_handshake_failures_total (counter)

health_checks:
  - /health/live (liveness)
  - /health/ready (readiness)
  - /health/startup (startup probe)
```

### Logging

```json
{
  "timestamp": "2025-11-04T15:30:00.123Z",
  "level": "INFO",
  "service": "mesh-api",
  "trace_id": "trace_abc123",
  "span_id": "span_def456",
  "event": "consent_check",
  "patient_id": "PAT-847392",
  "requestor_org": "hospital-b",
  "resource": "MedicationStatement",
  "operation": "read",
  "consent_valid": true,
  "decision": "ALLOWED",
  "duration_ms": 15
}
```

---

## Next Steps

1. Review [Event Schemas](event-schemas.md)
2. Understand [Consent Tokens](consent-tokens.md)
3. See [Integration Examples](../integration/ehr/)
4. Deploy [Pilot Configuration](../../deployments/pilot/)

---

*For questions: thomas@aetheris.consulting*
