# Observer Sentinel Specification

## Overview

The Observer is an **internal quality/safety watchdog AI** that monitors care delivery, detects potential issues, and alerts appropriate staff—all while respecting privacy and maintaining transparency.

**Key Principle**: Internal-only reporting. Observer does NOT communicate with patients, families, payers, or external organizations.

---

## Design Constraints

### Who Observer Reports To

**Primary Recipients**:
- Department Head (Clinical Ops / IT / Security)
- Internal Audit / Quality Improvement
- Compliance Officer

**Optional CC**:
- Risk Management (liability concerns)
- Privacy Officer (HIPAA violations)
- CMO/CNO (Tier 3 escalations)

**NEVER Reports To**:
- ❌ Patients (use their Patient AI instead)
- ❌ Family members (no direct access)
- ❌ Insurance companies (no visibility)
- ❌ External organization AIs (no cross-org communication)

---

## Severity Tiers & SLAs

### Tier 1: Quality Drift / Minor Policy Miss

**Examples**:
- Documentation incomplete (minor fields missing)
- Process delay (non-critical lab ordered late)
- Preference deviation (brand vs generic, both clinically OK)

**Routing**:
```
Team Lead → Department Head
```

**SLA**:
- Acknowledge: 24 hours
- Remediate: 7 days
- If missed: Auto-escalate to Tier 2

**Action**:
- Coaching
- Process improvement
- Documentation update

---

### Tier 2: Material Patient Impact / Policy Variance

**Examples**:
- Medication error caught before administration
- Care plan deviation needing justification
- Authorization denial causing treatment delay
- Discharge without required med reconciliation

**Routing**:
```
Department Head + Compliance + Audit
```

**SLA**:
- Acknowledge: 8 hours
- CAPA (Corrective/Preventive Action): 3 days
- If missed: Auto-escalate to Tier 3

**Action**:
- Root cause analysis
- Process fix
- Staff re-training
- Policy update

---

### Tier 3: Imminent Harm / Clear Legal Breach

**Examples**:
- Medication given despite documented allergy
- DNR violated (resuscitation performed when prohibited)
- Procedure on wrong patient (near miss or actual)
- Unauthorized data access (HIPAA breach)
- Billing fraud detected (upcoding, unbundling)

**Routing**:
```
Department Head + CMO/CNO + Compliance + Legal + Audit
(Auto-page all recipients)
```

**SLA**:
- Acknowledge: ≤ 1 hour (immediate)
- CAPA: 24 hours
- External reporting: If legally required (CMS, state board)
- If missed: Executive escalation (CEO/Board)

**Action**:
- Immediate intervention
- Full investigation
- Regulatory reporting (if required)
- Possible staff suspension
- Sentinel event review

---

## What Observer Detects

### 1. Care Plan Divergence

**Rule**: Ordered procedure contradicts documented directives

**Example**:
```yaml
scenario:
  patient_directive: "DNR/DNI - no resuscitation"
  doctor_order: "Intubation for respiratory distress"
  
observer_alert:
  severity: TIER_3
  message: "Potential DNR violation - verify patient consent"
  evidence:
    - advance_directive: "DNR/DNI signed 2024-03-15"
    - current_order: "Intubation ordered 2025-11-04"
    - patient_status: "Conscious, can be consulted"
  recommendation: "Confirm with patient before proceeding"
```

---

### 2. Medication Safety

**Rules**:
- Renal dosing violations
- Contraindicated drug combinations
- Documented allergy mismatches
- Pregnancy category violations
- Pediatric/geriatric dosing errors

**Example**:
```yaml
scenario:
  patient_creatinine: "3.5 mg/dL" # Stage 4 CKD
  drug_ordered: "Metformin 1000mg BID"
  standard_guidance: "Contraindicated if Cr > 1.5"
  
observer_alert:
  severity: TIER_2
  rule_id: "MED_SAFETY_001"
  message: "Renal dosing violation - metformin contraindicated"
  evidence:
    - creatinine: "3.5 mg/dL (Stage 4 CKD)"
    - drug: "Metformin 1000mg BID"
    - guideline: "FDA label: contraindicated if Cr > 1.5"
  recommendations:
    - action: "Discontinue metformin"
      rationale: "Risk of lactic acidosis"
    - action: "Switch to insulin"
      rationale: "Safe in renal impairment"
    - action: "Consult nephrology"
      rationale: "Complex case"
```

---

### 3. Authorization vs Care Mismatch

**Rule**: Payer denied recommended procedure, doctor proceeding without documented exception

**Example**:
```yaml
scenario:
  doctor_recommendation: "MRI lumbar spine"
  insurance_decision: "DENIED - try X-ray first per policy"
  doctor_action: "Ordered MRI anyway"
  documentation: "No exception rationale documented"
  
observer_alert:
  severity: TIER_2
  message: "Billing-care conflict - document clinical rationale"
  evidence:
    - payer_denial: "MRI denied, X-ray required first"
    - doctor_order: "MRI ordered without appeal"
    - guideline: "ACR appropriateness: MRI preferred for radiculopathy"
  recommendations:
    - action: "Document exception rationale"
      example: "Patient has contraindication to X-ray (pregnancy)"
    - action: "Appeal denial"
      rationale: "Provide clinical justification"
    - action: "Order X-ray first"
      rationale: "Follow payer pathway if clinically acceptable"
```

---

### 4. Documentation Gaps

**Rules**:
- Discharge without medication reconciliation
- Procedure without informed consent
- Missing teach-back documentation
- Incomplete handoff communication
- Missing fall risk assessment

**Example**:
```yaml
scenario:
  patient_status: "Discharge order entered"
  required_documentation:
    - medication_reconciliation: MISSING
    - discharge_instructions: PRESENT
    - follow_up_appointments: PRESENT
  
observer_alert:
  severity: TIER_2
  message: "Discharge documentation incomplete"
  evidence:
    - missing: "Medication reconciliation"
    - policy: "Required by Joint Commission standards"
    - risk: "30% of readmissions due to med errors"
  recommendation: "Complete med reconciliation before discharge"
```

---

### 5. Process Drift

**Rules**:
- Repeated handoff failures (ED → Floor delays)
- Delayed labs for high-risk pathways (sepsis protocol)
- Preventable readmissions (inadequate discharge planning)
- Clustering of near-misses (unit-level safety concern)

**Example**:
```yaml
scenario:
  pathway: "Sepsis Protocol"
  required_action: "Lactate drawn within 1 hour"
  actual_time: "2.5 hours"
  occurrences: "3rd instance this week on Unit 4B"
  
observer_alert:
  severity: TIER_2
  message: "Process drift detected - sepsis protocol delays"
  evidence:
    - pathway: "Sepsis-3 Protocol"
    - sla: "Lactate < 1 hour"
    - actual: "2.5 hours (missed SLA)"
    - unit: "4B (3 instances this week)"
    - outcome_risk: "10% higher mortality per hour delay"
  recommendations:
    - action: "Unit-level review"
      target: "Unit 4B leadership"
    - action: "Process audit"
      focus: "ED-to-Floor handoff timing"
    - action: "Staff education"
      topic: "Sepsis urgency, lactate prioritization"
```

---

## Evidence Bundle Format

### observer_case.json

```json
{
  "case_id": "obs_case_123456",
  "created_at": "2025-11-04T15:30:00Z",
  "severity": "TIER_2",
  "rule_id": "MED_SAFETY_001",
  "rule_name": "Renal Dosing Violation Detection",
  
  "alert": {
    "title": "Renal dosing violation - metformin contraindicated",
    "description": "Patient with Stage 4 CKD (Cr 3.5) prescribed metformin, which is contraindicated per FDA labeling and clinical guidelines.",
    "clinical_impact": "HIGH - Risk of lactic acidosis (life-threatening)"
  },
  
  "affected_resources": [
    {
      "type": "Patient",
      "id": "PAT-847392",
      "reference": "Patient/847392"
    },
    {
      "type": "MedicationRequest",
      "id": "med_req_789",
      "reference": "MedicationRequest/789"
    },
    {
      "type": "Observation",
      "id": "obs_creat_456",
      "reference": "Observation/456",
      "display": "Creatinine 3.5 mg/dL"
    }
  ],
  
  "evidence": {
    "patient_context": {
      "age": 72,
      "sex": "F",
      "diagnosis": "Type 2 Diabetes, CKD Stage 4",
      "creatinine": "3.5 mg/dL",
      "egfr": "22 mL/min/1.73m²"
    },
    "medication_ordered": {
      "name": "Metformin",
      "dose": "1000mg",
      "frequency": "BID",
      "route": "PO",
      "ordered_by": "Dr. Smith",
      "ordered_at": "2025-11-04T14:00:00Z"
    },
    "policy_violated": {
      "policy_id": "MED_001",
      "title": "Medication Safety - Renal Dosing",
      "excerpt": "Metformin is contraindicated in patients with eGFR < 30 mL/min due to risk of lactic acidosis."
    },
    "guideline_citation": {
      "source": "FDA Drug Label - Metformin",
      "section": "Contraindications",
      "text": "Do not use in patients with eGFR below 30 mL/min/1.73m²"
    },
    "clinical_evidence": {
      "risk": "Lactic acidosis",
      "incidence": "Rare but life-threatening when occurs",
      "mechanism": "Reduced renal clearance → metformin accumulation"
    }
  },
  
  "time_window": {
    "detection_time": "2025-11-04T15:30:00Z",
    "relevant_period": {
      "start": "2025-11-04T10:00:00Z",
      "end": "2025-11-04T15:30:00Z"
    }
  },
  
  "consent_policy_consulted": {
    "policy_id": "CONSENT_001",
    "result": "Observer authorized to access medication + lab data for safety monitoring"
  },
  
  "proposed_actions": [
    {
      "action": "Discontinue metformin",
      "rationale": "Contraindicated - high risk of lactic acidosis",
      "evidence_strength": "STRONG - FDA contraindication",
      "urgency": "IMMEDIATE"
    },
    {
      "action": "Switch to insulin therapy",
      "rationale": "Safe alternative for diabetes management in CKD",
      "evidence_strength": "STRONG - Standard of care",
      "urgency": "IMMEDIATE"
    },
    {
      "action": "Consult nephrology",
      "rationale": "Complex case - Stage 4 CKD requires specialist input",
      "evidence_strength": "MODERATE - Best practice",
      "urgency": "24-48 hours"
    }
  ],
  
  "signatures": {
    "observer_signature": "0xabc123...",
    "system_signature": "0xdef456...",
    "tenant_signature": "0xghi789..."
  },
  
  "ledger_record": {
    "ledger_id": "ledger_xyz",
    "merkle_leaf": "0xjkl012...",
    "merkle_path": ["0xmno345...", "0xpqr678..."],
    "block_height": 12345
  },
  
  "routing": {
    "primary_recipients": [
      "dept_head_clinical_ops@hospital.com",
      "quality_improvement@hospital.com"
    ],
    "cc_recipients": [
      "compliance_officer@hospital.com"
    ],
    "sla": {
      "acknowledge_by": "2025-11-04T23:30:00Z",
      "capa_by": "2025-11-07T23:30:00Z"
    }
  }
}
```

---

## Governance & Due Process

### Ownership

```yaml
primary_owner:
  role: "Department Head - Clinical Operations"
  responsibilities:
    - Review all Observer alerts
    - Approve CAPA plans
    - Sign off on remediation
    
co_owner:
  role: "Internal Audit / Quality Improvement"
  responsibilities:
    - Validate Observer accuracy
    - Calibrate thresholds
    - Report metrics to Quality Council

executive_sponsor:
  role: "CMO or CNO"
  responsibilities:
    - Strategic oversight
    - Resource allocation
    - Regulatory liaison
```

### Appeal Workflow

```yaml
appeal_process:
  step_1:
    actor: "Staff member who triggered alert"
    action: "Mark as false positive with rationale"
    deadline: "72 hours"
    
  step_2:
    actor: "Department Head"
    action: "Review appeal + supporting evidence"
    deadline: "48 hours"
    options:
      - UPHOLD: "Alert was valid, CAPA proceeds"
      - OVERTURN: "False positive, mark as such"
      - DEFER: "Unclear, send to Quality Council"
      
  step_3:
    actor: "Observer AI"
    action: "Learn from appeal decision"
    update: "Adjust rule thresholds if systematic FPs"
    
  step_4:
    actor: "Quality Council"
    action: "Quarterly review of all appeals"
    outcome: "Rule refinement, calibration updates"
```

### Sampling Review

```yaml
weekly_sampling:
  sample_size: "5-10% of all alerts (random)"
  reviewer: "Quality Improvement team"
  questions:
    - "Was alert clinically valid?"
    - "Was severity tier appropriate?"
    - "Were recommendations helpful?"
    - "Was routing correct?"
  outcome: "Feedback to Observer for tuning"

monthly_report:
  metrics:
    - false_positive_rate: "target < 5%"
    - false_negative_rate: "estimated via sampling, target < 10%"
    - time_to_acknowledge: "% meeting SLA"
    - time_to_close: "% meeting SLA"
    - appeal_rate: "% of alerts appealed, target < 10%"
  recipient: "Quality Council"
  
annual_audit:
  auditor: "External auditing firm (optional)"
  scope: "Observer performance, bias check, compliance"
  outcome: "Certification report"
```

---

## Privacy Guardrails

### Data Minimization

```yaml
rule_MED_SAFETY_001:
  name: "Renal Dosing Violation Detection"
  data_access:
    required_fields:
      - Patient.id
      - Observation.creatinine.value
      - MedicationRequest.medication
      - MedicationRequest.dosage
    forbidden_fields:
      - Patient.name
      - Patient.address
      - DocumentReference.clinicalNotes
      - Encounter.privateNotes
  rationale: "Only access what's needed for safety check"
```

### Purpose Binding

Every Observer rule must declare its purpose:

```yaml
rule_metadata:
  rule_id: "MED_SAFETY_001"
  purpose: "Medication safety - prevent renal dosing errors"
  legal_basis: "Healthcare quality improvement (HIPAA permitted use)"
  policy_mapping: "Hospital Policy MED-001: Medication Safety"
  cannot_be_used_for:
    - "Performance evaluation of individual clinicians"
    - "Marketing or commercial purposes"
    - "Insurance underwriting"
```

### Access Control

```yaml
observer_service_account:
  permissions:
    - read: ["MedicationRequest", "Observation", "Condition"]
    - write: ["ObserverCase", "AuditLog"]
    - forbidden: ["update_patient_record", "delete_data"]
  
  least_privilege: true
  every_query_logged: true
  audit_review: "Quarterly"
```

### Human Visibility

```yaml
transparency_requirements:
  - rule_catalog:
      published: true
      location: "Internal staff portal"
      content: "All active rules with explanations"
      
  - staff_dashboard:
      who_can_see: "All clinical staff"
      what_they_see:
        - Active rules Observer is running
        - Why each rule exists (policy citation)
        - How to appeal if false positive
        
  - no_hidden_checks:
      requirement: "Every rule must be published internally"
      rationale: "Transparency prevents surveillance concerns"
```

---

## Optional External Oversight (Future)

**Config Switch**: `observer.export.enable=false` (default)

If enabled (requires exec approval + legal review):

```yaml
external_export:
  recipient: "Nonprofit Observer Foundation (if created)"
  
  data_exported:
    - alert_counts_by_type: "Anonymized aggregates"
    - time_to_close_metrics: "No patient identifiers"
    - capa_completion_rates: "Quality metrics only"
    - NO_PHI: true
    - NO_individual_cases: true
    
  purpose:
    - "Benchmarking vs peer hospitals"
    - "External credibility (third-party validation)"
    - "Grant eligibility / insurance incentives"
    
  legal:
    - BAA_DUA_addendum: required
    - published_thresholds: required
    - revocable: "Org can disable anytime"
    
  value:
    - "Comparative analytics (how we perform vs peers)"
    - "Public transparency (builds trust)"
    - "Financial incentives (insurer discounts)"
```

**Default**: Internal-only. External layer is opt-in enhancement, not requirement.

---

## Deployment Checklist

- [ ] Deploy Observer with read-only service roles
- [ ] Load rule catalog (start with high-confidence rules)
- [ ] Shadow mode 2-4 weeks (alerts generated, not sent)
- [ ] Compare shadow alerts to existing incident logs (calibrate)
- [ ] Go-live Tier 2/3 only
- [ ] Keep Tier 1 in shadow for another 2 weeks
- [ ] Weekly sampling review (validate accuracy)
- [ ] Monthly KPI report to Quality Council
- [ ] Quarterly rule calibration (adjust thresholds)
- [ ] Annual external audit (optional)

---

## Success Metrics

```yaml
quality_metrics:
  false_positive_rate: "< 5%"
  false_negative_rate: "< 10%"
  staff_satisfaction: "> 70% find Observer helpful"
  
operational_metrics:
  time_to_acknowledge: "> 90% meet SLA"
  time_to_close: "> 85% meet SLA"
  capa_completion: "> 95% within deadline"
  
safety_impact:
  medication_errors_prevented: "Measure before/after"
  policy_violations_reduced: "> 30% reduction year-over-year"
  near_miss_captures: "Increase detection by > 50%"
```

---

*For questions: thomas@aetheris.consulting*
