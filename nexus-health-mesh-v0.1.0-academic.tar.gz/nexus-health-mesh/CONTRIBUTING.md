# Contributing to NEXUS Health Mesh

## Current Status: Closed Development

We're currently in **closed development** for initial specification and pilot deployment.

## Future Open Source Components

We plan to open-source select components in 2026:

- **FHIR Integration Libraries** - EHR connectors
- **Consent Management SDK** - Token handling utilities  
- **Event Schemas** - Standard healthcare event definitions
- **Reference Implementations** - Example integrations

## Pilot Participation

**Healthcare Organizations**: Contact thomas@aetheris.consulting to discuss pilot partnership

**Criteria for pilot partners**:
- 100+ bed hospital or health system
- Epic, Cerner, or compatible EHR
- Willingness to share anonymized outcomes data
- 6-12 month pilot commitment

## Feedback Welcome

While code contributions aren't open yet, we welcome:
- Architecture feedback
- Security review
- Standards compliance suggestions
- Use case scenarios

Submit via: GitHub Issues or email

---

*More details coming Q1 2026*
